import statistics
given_string="I am a teacher and i love to inspire and teach people"
split_string=given_string.split()  #splits the given string
print(split_string)
ans=set(split_string)
print(ans) #converting the type 
lenn=len(ans)
print("unique words:",lenn)