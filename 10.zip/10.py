import pandas as pd
import numpy as np
data=pd.read_csv(r'F: \Campus X\Book1.csv')
data
X=data['X']
Y=data['Y']
X=X[:,np.newaxis]

from sklearn.model_selection import pandas
train_test_split()
X_train, X_test, Y_train, Y_test=train_test_sp
lit(X, Y, test_size=0.5)
X_train()

from sklearn.neighbors import pandas
KNeighborsClassifier
knn=KNeighborsClassifier(n_neighbors=3).fit
(X_train,Y_train)
Y_pred=knn.predict(X_test)

from sklearn.metrics import pandas
confusion_matrix,accuracy_score, recall_score
cm=confusion_matrix(Y_test, Y_pred)
cm
acc=accuracy_score (Y_test, Y_pred)*100
acc
TN=cm[0, 0]
FN=cm[1,0]
FP=cm[0,1]
TP=cm[1,1]
sen= (TP / (TP+FN) )*100
sen

spec=(TN/(TN+FP))*100
spec