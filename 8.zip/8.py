import statistics
given_radius= 10
area=3.14*given_radius**2 #String formatting is the process of infusing things in the string dynamically and presenting the string.
print("the area of circle with given radius {} is {} meter square.".format(given_radius,int(area)))