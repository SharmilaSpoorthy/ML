import statistics
it_companies ={'facebook','google','microsoft','apple','IBM','ORACLE','Amazon'} #creating a set and assigning values 
print("lenght of the companies:")
len(it_companies)  #len() return the length of the set 
it_companies.add("twitter") #add() is used to add new values to the set
print(it_companies)
new_companies= {"Samsung", "JP morgan","control s", "SONY", 'VIVO','Accenture','TATA CONSULTANCY'}
it_companies.update(new_companies) #adding multiple values to the set using update 
print(it_companies)
it_companies.remove("Accenture") #removing the value from the set if the values exists it throws error ;remove()
print(it_companies)
##remove: error message will pop up onto the screen when there is no such element in the set which we want to remove(delete)
###discard: removes the desired element and no change in output if there is no such element present in a set
A={19,22,24,20,25,26}
B={19,22,20,25, 26, 24, 28, 27}
print(A.union(B))      #union() operation of joining two sets
print(A.intersection(B))  #intersection() of A and B; it returns the common terms from two sets 
print(A.issubset (B))      #issusbet() return boolean value wheather b is subset of a or not 
print(A.isdisjoint(B))      #isdisjoint() return boolean value wheather b is disjoint sets or not 
print(A.union(B)&B.union(A))  #join A and B with B and A
print(A.symmetric_difference(B)) #symmetric difference
A.clear()    #clear() is used for deleting the set
print (A)
age=[22,19,24,25,26,24,25,24]
diff_in_age=len(age)
print(diff_in_age)
diff_in_age=set(age) #type conversion from list to set 
length=len(diff_in_age)
print(length)