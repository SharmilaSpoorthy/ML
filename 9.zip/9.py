conversionante=0.45
v=int(input("number of students")) #reading the input from the user
l1=[] #empty list creation 
l2=[]
for i in range(v):
    ele=input()
    l1.append(int(input("enter weight in lbs:"+str(i)+" "))) # reading user input and appending to the list 
    l2.append(round(l1[i]*0.453,2)) #using mathematical operators converting lbs to kg 
print("given weights in lbs:",l1)
print("converted weights in kgs:",l2)