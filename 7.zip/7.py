import statistics   
given_sequence="name\t age\t country\t city\t Asabeneh\t 250\t Finland\t Helsinki"  #using escape sequence
print(given_sequence)