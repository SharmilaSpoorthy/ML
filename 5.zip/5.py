from math import pi
import statistics
radius = 30
pi=3.14
area_of_circle = pi*radius**2  # Area of circle formula
print("area of circle" ,area_of_circle)
result = 'the area of circle with {} is {}' .format (str(radius), str(area_of_circle))
circum_of_circle = 2*3.14*radius
print ("circum of circle",circum_of_circle)  #area of cirumcumference formula
r=float(input ()) #user enters the input and it is assgined to a variable
raadius=10
area_of_circle=pi*raadius**2
print(area_of_circle)