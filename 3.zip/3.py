import statistics    #creating tuple and assigning values to it
bro_1=('saketh', 'manoj','rohith','sunil','joseph','satwik','vinod','nirosh','karthik')
sis_2=('priyanka', 'annie','akshitha', 'pravalika','anshika', 'anusha','rushika', 'ruchitha', 'madhu')
my_siblings_3=bro_1+sis_2  #using + operator we can join both 
print(my_siblings_3)
print("length of my siblings: ",len(my_siblings_3))
family_members=my_siblings_3 + ("ARUN REDDY","Swarna Latha") #adding new values to the tuple
print(family_members)