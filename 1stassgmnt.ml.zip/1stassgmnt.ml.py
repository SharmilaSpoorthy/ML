import statistics
ages=[19, 22, 19, 24, 20, 25, 26, 24, 25, 24] #assigning ages to the list named ages
ages.sort() #sorting the ages using predefined method called sort()
print (ages)
min_age_from_list=min(ages) # creation of the variable named minimum to find out the min value in the list using min()function
print("min age from the give list:",min_age_from_list)
max_age_from_list=max (ages) # creation of the variable named maximum to fint the max value in the list using max()function
print ("max age from the give list:",max_age_from_list)
min_age=19
ages.append(min_age) #appends the object to the end of the list 
max_age=26
ages.append(max_age)
print(ages)
avg_age= statistics.mean(ages) #finds the avg by adding of all items divided by their numbers 
print("average of ages:", avg_age)
median_age=statistics.median(ages)
print ("median of ages:",median_age) # finds the median value from the list which is one middle item or two middle items divided by two
print("lenght of ages:",len(ages)) 
range_of_ages= max_age - min_age #range () is a built-in function of Python. It is used when a user needs to perform an action for a specific number of times.
print("range of ages:", range_of_ages)