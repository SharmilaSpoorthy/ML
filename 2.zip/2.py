import statistics
dog={} #empty dictonary created
print (type(dog)) #dictonaries are used to store data values in key:values pairs, ordered ,and can be changeable and do not allow duplicates
dog["name"] = "hash"
dog["color"]="black" #tuples are hastable objects and can be used as a key or value 
dog["breed"]="german shepard"  #creating a dictonary called student_ and assigning keys and values 
dog["legs"]="04"
dog["age"]="02"
print(dog)
stud_dict={}
stud_dict["first name"]="spoorthy" #creating of key : value pair
stud_dict["last name"]="Pothi Reddy"
stud_dict["address"] ="10215 W 118TH TERRACE UNIT"
stud_dict["city"]="Kansas city"
stud_dict["age"]="22"
stud_dict["skills"]=(' JAVA', 'PYTHON', 'DATA STRUCTURES', 'R', '.NET','ARTIFICIAL INTELLIGENCE')
stud_dict["martial status"]="single"
stud_dict["country"]="USA"
print(stud_dict)  #prints the type of the variable
length= len (stud_dict)
print("length of the student dictionary:",len(stud_dict)) 
stud_dict["skills"]=list('C')
print(stud_dict["skills"]) 
print(type(stud_dict["skills"]))
print (stud_dict.keys())   ##returns the keys in student dictonary
print (stud_dict.values()) ##returns the values in student dictonary
